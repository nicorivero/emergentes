namespace api_tecn_emergentes.Models
{
    public class Parametros
    {
        public int id_entidad {get; set;}
        public double max {get; set;}
        public double min {get; set;}
    }
}